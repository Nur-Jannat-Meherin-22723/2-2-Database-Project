<?php
	
	$db=mysqli_connect("localhost","root","","lib");  
					/* server name, username, password, database name */


	

?>

