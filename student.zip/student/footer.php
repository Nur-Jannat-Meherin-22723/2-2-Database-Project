<!DOCTYPE html>
<html>
<head>
	<title></title>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<style type="text/css">
	footer
	{
		height: 120px;
		width: 1534px;
		background-color: #F6E4D9;
	}
		.fa
		{
			margin: 0px 5px;
			padding: 5px;
			font-size: 20px;
			width: 20px;
			height: 20px;
			text-align: center;
			text-decoration: none;
			border-radius: 50%;
		}
		.fa:hover
		{
			opacity: .7;
		}
		.fa-facebook
		{
			background: #3B5998;
			color: white;
		}
		.fa-twitter
		{
			background: #55ACEE;
			color: white;
		}
		.fa-google
		{
			background: #dd4b39;
			color: white;
		}
		.fa-instagram
		{
			background: #125688;
			color: white;
		}
		.fa-yahoo
		{
			background: #400297;
			color: white;
		}
	</style>

</head>
<body>
<footer style="background-color: #F6E4D9; ">
	<br>
	<h3 style="color:#880808;text-align: center;">Contact us through social media</h3><br>

	<div style="margin:0px 570px;">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

		<a href="https://www.facebook.com" class="fa fa-facebook"></a>
		<a href="https://www.twitter.com" class="fa fa-twitter"></a>
		<a href="https://www.google.com" class="fa fa-google"></a>
		<a href="https://www.instagram.com" class="fa fa-instagram"></a>
		<a href="https://www.yahoo.com" class="fa fa-yahoo"></a>
	</div>

	
	<p style="color:#880808; text-align:center;">
				<br><b>
				Email: &nbsp csedulibrary@gmail.com<br>
				Mobile:&nbsp 01874620144</b>
			</p>
</footer>
</body>
</html>